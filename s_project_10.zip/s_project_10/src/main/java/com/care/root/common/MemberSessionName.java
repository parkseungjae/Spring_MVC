package com.care.root.common;

public interface MemberSessionName {
	static final String LOGIN = "loginUser";
}
